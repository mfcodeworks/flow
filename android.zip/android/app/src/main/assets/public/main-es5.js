function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(n); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
  /*!*****************************************************************************************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
    \*****************************************************************************************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesIonicCoreDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
    var map = {
      "./ion-action-sheet-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js", "common", "stencil-ion-action-sheet-ios-entry-js"],
      "./ion-action-sheet-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js", "common", "stencil-ion-action-sheet-md-entry-js"],
      "./ion-alert-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js", "common", "stencil-ion-alert-ios-entry-js"],
      "./ion-alert-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js", "common", "stencil-ion-alert-md-entry-js"],
      "./ion-app_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js", "common", "stencil-ion-app_8-ios-entry-js"],
      "./ion-app_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js", "common", "stencil-ion-app_8-md-entry-js"],
      "./ion-avatar_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js", "common", "stencil-ion-avatar_3-ios-entry-js"],
      "./ion-avatar_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js", "common", "stencil-ion-avatar_3-md-entry-js"],
      "./ion-back-button-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js", "common", "stencil-ion-back-button-ios-entry-js"],
      "./ion-back-button-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js", "common", "stencil-ion-back-button-md-entry-js"],
      "./ion-backdrop-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js", "stencil-ion-backdrop-ios-entry-js"],
      "./ion-backdrop-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js", "stencil-ion-backdrop-md-entry-js"],
      "./ion-button_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js", "common", "stencil-ion-button_2-ios-entry-js"],
      "./ion-button_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js", "common", "stencil-ion-button_2-md-entry-js"],
      "./ion-card_5-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js", "common", "stencil-ion-card_5-ios-entry-js"],
      "./ion-card_5-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js", "common", "stencil-ion-card_5-md-entry-js"],
      "./ion-checkbox-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js", "common", "stencil-ion-checkbox-ios-entry-js"],
      "./ion-checkbox-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js", "common", "stencil-ion-checkbox-md-entry-js"],
      "./ion-chip-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js", "common", "stencil-ion-chip-ios-entry-js"],
      "./ion-chip-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js", "common", "stencil-ion-chip-md-entry-js"],
      "./ion-col_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js", "stencil-ion-col_3-entry-js"],
      "./ion-datetime_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js", "common", "stencil-ion-datetime_3-ios-entry-js"],
      "./ion-datetime_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js", "common", "stencil-ion-datetime_3-md-entry-js"],
      "./ion-fab_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js", "common", "stencil-ion-fab_3-ios-entry-js"],
      "./ion-fab_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js", "common", "stencil-ion-fab_3-md-entry-js"],
      "./ion-img.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-img.entry.js", "stencil-ion-img-entry-js"],
      "./ion-infinite-scroll_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js", "common", "stencil-ion-infinite-scroll_2-ios-entry-js"],
      "./ion-infinite-scroll_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js", "common", "stencil-ion-infinite-scroll_2-md-entry-js"],
      "./ion-input-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js", "common", "stencil-ion-input-ios-entry-js"],
      "./ion-input-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js", "common", "stencil-ion-input-md-entry-js"],
      "./ion-item-option_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js", "common", "stencil-ion-item-option_3-ios-entry-js"],
      "./ion-item-option_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js", "common", "stencil-ion-item-option_3-md-entry-js"],
      "./ion-item_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js", "common", "stencil-ion-item_8-ios-entry-js"],
      "./ion-item_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js", "common", "stencil-ion-item_8-md-entry-js"],
      "./ion-loading-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js", "common", "stencil-ion-loading-ios-entry-js"],
      "./ion-loading-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js", "common", "stencil-ion-loading-md-entry-js"],
      "./ion-menu_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-ios.entry.js", "common", "stencil-ion-menu_3-ios-entry-js"],
      "./ion-menu_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-md.entry.js", "common", "stencil-ion-menu_3-md-entry-js"],
      "./ion-modal-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js", "common", "stencil-ion-modal-ios-entry-js"],
      "./ion-modal-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js", "common", "stencil-ion-modal-md-entry-js"],
      "./ion-nav_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js", "common", "stencil-ion-nav_2-entry-js"],
      "./ion-popover-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js", "common", "stencil-ion-popover-ios-entry-js"],
      "./ion-popover-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js", "common", "stencil-ion-popover-md-entry-js"],
      "./ion-progress-bar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js", "common", "stencil-ion-progress-bar-ios-entry-js"],
      "./ion-progress-bar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js", "common", "stencil-ion-progress-bar-md-entry-js"],
      "./ion-radio_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js", "common", "stencil-ion-radio_2-ios-entry-js"],
      "./ion-radio_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js", "common", "stencil-ion-radio_2-md-entry-js"],
      "./ion-range-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js", "common", "stencil-ion-range-ios-entry-js"],
      "./ion-range-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js", "common", "stencil-ion-range-md-entry-js"],
      "./ion-refresher_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js", "common", "stencil-ion-refresher_2-ios-entry-js"],
      "./ion-refresher_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js", "common", "stencil-ion-refresher_2-md-entry-js"],
      "./ion-reorder_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js", "common", "stencil-ion-reorder_2-ios-entry-js"],
      "./ion-reorder_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js", "common", "stencil-ion-reorder_2-md-entry-js"],
      "./ion-ripple-effect.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js", "stencil-ion-ripple-effect-entry-js"],
      "./ion-route_4.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js", "common", "stencil-ion-route_4-entry-js"],
      "./ion-searchbar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js", "common", "stencil-ion-searchbar-ios-entry-js"],
      "./ion-searchbar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js", "common", "stencil-ion-searchbar-md-entry-js"],
      "./ion-segment_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js", "common", "stencil-ion-segment_2-ios-entry-js"],
      "./ion-segment_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js", "common", "stencil-ion-segment_2-md-entry-js"],
      "./ion-select_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js", "common", "stencil-ion-select_3-ios-entry-js"],
      "./ion-select_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js", "common", "stencil-ion-select_3-md-entry-js"],
      "./ion-slide_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js", "stencil-ion-slide_2-ios-entry-js"],
      "./ion-slide_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js", "stencil-ion-slide_2-md-entry-js"],
      "./ion-spinner.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js", "common", "stencil-ion-spinner-entry-js"],
      "./ion-split-pane-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js", "stencil-ion-split-pane-ios-entry-js"],
      "./ion-split-pane-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js", "stencil-ion-split-pane-md-entry-js"],
      "./ion-tab-bar_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js", "common", "stencil-ion-tab-bar_2-ios-entry-js"],
      "./ion-tab-bar_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js", "common", "stencil-ion-tab-bar_2-md-entry-js"],
      "./ion-tab_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js", "common", "stencil-ion-tab_2-entry-js"],
      "./ion-text.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-text.entry.js", "common", "stencil-ion-text-entry-js"],
      "./ion-textarea-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js", "common", "stencil-ion-textarea-ios-entry-js"],
      "./ion-textarea-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js", "common", "stencil-ion-textarea-md-entry-js"],
      "./ion-toast-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js", "common", "stencil-ion-toast-ios-entry-js"],
      "./ion-toast-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js", "common", "stencil-ion-toast-md-entry-js"],
      "./ion-toggle-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js", "common", "stencil-ion-toggle-ios-entry-js"],
      "./ion-toggle-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js", "common", "stencil-ion-toggle-md-entry-js"],
      "./ion-virtual-scroll.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js", "stencil-ion-virtual-scroll-entry-js"]
    };

    function webpackAsyncContext(req) {
      if (!__webpack_require__.o(map, req)) {
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      var ids = map[req],
          id = ids[0];
      return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
        return __webpack_require__(id);
      });
    }

    webpackAsyncContext.keys = function webpackAsyncContextKeys() {
      return Object.keys(map);
    };

    webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
    module.exports = webpackAsyncContext;
    /***/
  },

  /***/
  "./node_modules/@ionic/pwa-elements/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
  /*!*************************************************************************************************************************************************!*\
    !*** ./node_modules/@ionic/pwa-elements/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
    \*************************************************************************************************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesIonicPwaElementsDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
    var map = {
      "./pwa-action-sheet.entry.js": ["./node_modules/@ionic/pwa-elements/dist/esm/pwa-action-sheet.entry.js", 0],
      "./pwa-camera-modal-instance.entry.js": ["./node_modules/@ionic/pwa-elements/dist/esm/pwa-camera-modal-instance.entry.js", 1],
      "./pwa-camera-modal.entry.js": ["./node_modules/@ionic/pwa-elements/dist/esm/pwa-camera-modal.entry.js", 2],
      "./pwa-camera.entry.js": ["./node_modules/@ionic/pwa-elements/dist/esm/pwa-camera.entry.js", 3],
      "./pwa-toast.entry.js": ["./node_modules/@ionic/pwa-elements/dist/esm/pwa-toast.entry.js", 4]
    };

    function webpackAsyncContext(req) {
      if (!__webpack_require__.o(map, req)) {
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      var ids = map[req],
          id = ids[0];
      return __webpack_require__.e(ids[1]).then(function () {
        return __webpack_require__(id);
      });
    }

    webpackAsyncContext.keys = function webpackAsyncContextKeys() {
      return Object.keys(map);
    };

    webpackAsyncContext.id = "./node_modules/@ionic/pwa-elements/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
    module.exports = webpackAsyncContext;
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _shared_guards_signed_out_guard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./shared/guards/signed-out.guard */
    "./src/app/shared/guards/signed-out.guard.ts");
    /* harmony import */


    var _shared_guards_signed_in_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./shared/guards/signed-in.guard */
    "./src/app/shared/guards/signed-in.guard.ts"); // const routes: Routes = [
    //     {
    //         path: '',
    //         redirectTo: 'folder/Inbox',
    //         pathMatch: 'full'
    //     },
    //     {
    //         path: 'folder/:id',
    //         loadChildren: () => import('./folder/folder.module').then( m => m.FolderPageModule)
    //     }
    // ];


    var routes = [{
      path: '',
      canActivate: [_shared_guards_signed_in_guard__WEBPACK_IMPORTED_MODULE_3__["SignedInGuard"]],
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | main-main-module */
        "main-main-module").then(__webpack_require__.bind(null,
        /*! ./main/main.module */
        "./src/app/main/main.module.ts")).then(function (m) {
          return m.MainModule;
        });
      }
    }, {
      path: '',
      canActivate: [_shared_guards_signed_out_guard__WEBPACK_IMPORTED_MODULE_2__["SignedOutGuard"]],
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | authentication-authentication-module */
        "authentication-authentication-module").then(__webpack_require__.bind(null,
        /*! ./authentication/authentication.module */
        "./src/app/authentication/authentication.module.ts")).then(function (m) {
          return m.AuthenticationModule;
        });
      }
    }];
    var options = {
      useHash: false,
      scrollPositionRestoration: 'enabled',
      anchorScrolling: 'enabled',
      onSameUrlNavigation: 'reload',
      preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_1__["PreloadAllModules"]
    };

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: AppRoutingModule
    });
    AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      factory: function AppRoutingModule_Factory(t) {
        return new (t || AppRoutingModule)();
      },
      imports: [[// RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
      _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, options)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
    });

    (function () {
      (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, {
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
      });
    })();
    /*@__PURE__*/


    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
          imports: [// RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
          _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, options)],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./services/auth/auth.service */
    "./src/app/services/auth/auth.service.ts");
    /* harmony import */


    var _services_user_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./services/user/user.service */
    "./src/app/services/user/user.service.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _shared_components_top_bar_top_bar_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./shared/components/top-bar/top-bar.component */
    "./src/app/shared/components/top-bar/top-bar.component.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    function AppComponent_ng_container_10_ion_menu_toggle_1_ion_icon_2_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ion-icon", 0);
      }

      if (rf & 2) {
        var l_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](l_r2.icon);
      }
    }

    function AppComponent_ng_container_10_ion_menu_toggle_1_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-menu-toggle", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-item", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, AppComponent_ng_container_10_ion_menu_toggle_1_ion_icon_2_Template, 1, 3, "ion-icon", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "ion-label");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var l_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", l_r2 == null ? null : l_r2.link)("queryParams", l_r2 == null ? null : l_r2.params);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", l_r2 == null ? null : l_r2.icon);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](l_r2.name);
      }
    }

    function AppComponent_ng_container_10_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AppComponent_ng_container_10_ion_menu_toggle_1_Template, 5, 4, "ion-menu-toggle", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
      }

      if (rf & 2) {
        var l_r2 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", l_r2.condition);
      }
    }

    function AppComponent_ion_menu_toggle_12_Template(rf, ctx) {
      if (rf & 1) {
        var _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-menu-toggle", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-item", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_ion_menu_toggle_12_Template_ion_item_click_1_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r8);

          var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r7.doSignOut();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ion-label");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Logout");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    var AppComponent = /*#__PURE__*/function () {
      function AppComponent(platform, splashScreen, statusBar, user$, auth) {
        _classCallCheck(this, AppComponent);

        var _a;

        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.user$ = user$;
        this.auth = auth;
        this.mainLinks$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([{
          name: 'Wallet',
          icon: 'fas fa-wallet',
          link: '/',
          condition: true
        }, {
          name: 'Withdraw',
          icon: 'fas fa-coins',
          link: '/withdraw',
          condition: !!((_a = this.user$.profile) === null || _a === void 0 ? void 0 : _a.stripeConnectId)
        }, {
          name: 'Search',
          icon: 'fas fa-search-dollar',
          link: '/search',
          condition: true
        }, {
          name: 'Profile',
          icon: 'fas fa-qrcode',
          link: '/profile/me',
          condition: true
        }, {
          name: 'Top-up Wallet',
          icon: 'fas fa-hand-holding-usd',
          link: '/transaction/create',
          params: {
            to: 'me'
          },
          condition: true
        }, {
          name: 'Settings',
          icon: 'fas fa-cog',
          link: '/settings',
          condition: true
        }]);
        this.authLinks$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([{
          name: 'Login',
          icon: 'fas fa-sign-in-alt',
          link: '/login',
          condition: true
        }, {
          name: 'Sign Up',
          icon: 'fas fa-user-plus',
          link: '/register',
          condition: true
        }, {
          name: 'Reset Password',
          icon: 'fas fa-key',
          link: '/password/reset',
          condition: true
        }]);
        this.menuLinks$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"](this.authLinks$);
        this.initializeApp();
      }

      _createClass(AppComponent, [{
        key: "initializeApp",
        value: function initializeApp() {
          var _this = this;

          this.platform.ready().then(function () {
            _this.statusBar.styleDefault();

            _this.splashScreen.hide();
          });
        }
      }, {
        key: "doSignOut",
        value: function doSignOut() {
          this.auth.doSignOut();
        }
      }, {
        key: "userSignedIn",
        value: function userSignedIn() {
          return this.auth.isLoggedIn();
        }
      }, {
        key: "activeLinks",
        value: function activeLinks() {
          var _this2 = this;

          return this.menuLinks$.pipe( // Switch auth status
          Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["mergeMap"])(function () {
            return _this2.userSignedIn();
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(function (m) {
            return console.log('auth.isLoggedIn', m);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["distinctUntilChanged"])(), // Return app links or auth links
          Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["mergeMap"])(function (l) {
            return l ? _this2.mainLinks$ : _this2.authLinks$;
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(function (m) {
            return console.log('Menu links', m);
          }));
        }
      }]);

      return AppComponent;
    }();

    AppComponent.ɵfac = function AppComponent_Factory(t) {
      return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_user_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]));
    };

    AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: AppComponent,
      selectors: [["app-root"]],
      decls: 15,
      vars: 6,
      consts: [["slot", "start"], ["id", "main-menu-toggle", "menu", "dir"], ["slot", "icon-only", "name", "menu-outline"], ["contentId", "main"], ["side", "start", "menuId", "dir", "contentId", "main", "type", "overlay"], ["id", "dir-list"], [4, "ngFor", "ngForOf"], ["auto-hide", "false", 4, "ngIf"], ["id", "main"], ["auto-hide", "false"], ["routerDirection", "root", "detail", "false", 3, "routerLink", "queryParams"], ["slot", "start", 3, "class", 4, "ngIf"], ["button", "", "detail", "false", 3, "click"]],
      template: function AppComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-app");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "app-top-bar");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ion-buttons", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "ion-menu-toggle", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ion-button");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "ion-icon", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "ion-split-pane", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-menu", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "ion-content");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "ion-list", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, AppComponent_ng_container_10_Template, 2, 1, "ng-container", 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](11, "async");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, AppComponent_ion_menu_toggle_12_Template, 4, 0, "ion-menu-toggle", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](13, "async");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "ion-router-outlet", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](11, 2, ctx.activeLinks()));

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](13, 4, ctx.userSignedIn()));
        }
      },
      directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonApp"], _shared_components_top_bar_top_bar_component__WEBPACK_IMPORTED_MODULE_8__["TopBarComponent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonButtons"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonMenuToggle"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonIcon"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonSplitPane"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonMenu"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonList"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonRouterOutlet"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonItem"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["RouterLinkDelegate"], _angular_router__WEBPACK_IMPORTED_MODULE_10__["RouterLink"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonLabel"]],
      pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["AsyncPipe"]],
      styles: ["ion-split-pane[_ngcontent-%COMP%] {\n  top: 56px;\n}\nion-icon[_ngcontent-%COMP%] {\n  width: 32px;\n}\n\n@media (min-width: 992px) {\n  #main-menu-toggle[_ngcontent-%COMP%] {\n    display: none;\n  }\n}\n\n@media (min-width: 768px) {\n  ion-split-pane[_ngcontent-%COMP%] {\n    --side-max-width: 12%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQzpcXFVzZXJzXFxBU1VTXFxEb2N1bWVudHNcXFByb2plY3RzXFx1bGZ1clxcZmxvdy9zcmNcXGFwcFxcYXBwLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEscUNBQUE7QUFDQTtFQUNJLFNBQUE7QUNDSjtBRENBO0VBQ0ksV0FBQTtBQ0VKO0FEQ0EsdUNBQUE7QUFDQTtFQUNJO0lBQ0ksYUFBQTtFQ0VOO0FBQ0Y7QURBQSw2QkFBQTtBQUNBO0VBQ0k7SUFDSSxxQkFBQTtFQ0VOO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBTZXQgZGVmYXVsdCBzYWZlIHNwYWNlIGFuZCB3aWR0aCAqL1xuaW9uLXNwbGl0LXBhbmUge1xuICAgIHRvcDogNTZweDtcbn1cbmlvbi1pY29uIHtcbiAgICB3aWR0aDogMzJweDtcbn1cblxuLyogSGlkZSBtZW51IGJ1dHRvbiBmb3IgbGFyZ2Ugc2NyZWVucyAqL1xuQG1lZGlhKG1pbi13aWR0aDogOTkycHgpIHtcbiAgICAjbWFpbi1tZW51LXRvZ2dsZSB7XG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxufVxuLyogU2V0IHNlY29uZGFyeSBzYWZlIHNwYWNlICovXG5AbWVkaWEobWluLXdpZHRoOiA3NjhweCkge1xuICAgIGlvbi1zcGxpdC1wYW5lIHtcbiAgICAgICAgLS1zaWRlLW1heC13aWR0aDogMTIlO1xuICAgIH1cbn0iLCIvKiBTZXQgZGVmYXVsdCBzYWZlIHNwYWNlIGFuZCB3aWR0aCAqL1xuaW9uLXNwbGl0LXBhbmUge1xuICB0b3A6IDU2cHg7XG59XG5cbmlvbi1pY29uIHtcbiAgd2lkdGg6IDMycHg7XG59XG5cbi8qIEhpZGUgbWVudSBidXR0b24gZm9yIGxhcmdlIHNjcmVlbnMgKi9cbkBtZWRpYSAobWluLXdpZHRoOiA5OTJweCkge1xuICAjbWFpbi1tZW51LXRvZ2dsZSB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxufVxuLyogU2V0IHNlY29uZGFyeSBzYWZlIHNwYWNlICovXG5AbWVkaWEgKG1pbi13aWR0aDogNzY4cHgpIHtcbiAgaW9uLXNwbGl0LXBhbmUge1xuICAgIC0tc2lkZS1tYXgtd2lkdGg6IDEyJTtcbiAgfVxufSJdfQ== */"],
      changeDetection: 0
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-root',
          templateUrl: 'app.component.html',
          styleUrls: ['app.component.scss'],
          changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].OnPush
        }]
      }], function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"]
        }, {
          type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"]
        }, {
          type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"]
        }, {
          type: _services_user_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"]
        }, {
          type: _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser/animations */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/animations.js");
    /* harmony import */


    var _angular_fire__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/fire */
    "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire.js");
    /* harmony import */


    var _angular_fire_messaging__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/fire/messaging */
    "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-messaging.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _angular_service_worker__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/service-worker */
    "./node_modules/@angular/service-worker/__ivy_ngcc__/fesm2015/service-worker.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _material_material_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./material/material.module */
    "./src/app/material/material.module.ts");
    /* harmony import */


    var _shared_interceptors_jwt_interceptor__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./shared/interceptors/jwt.interceptor */
    "./src/app/shared/interceptors/jwt.interceptor.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _services_zoom_zoom_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ./services/zoom/zoom.service */
    "./src/app/services/zoom/zoom.service.ts");
    /* harmony import */


    var _services_theme_theme_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! ./services/theme/theme.service */
    "./src/app/services/theme/theme.service.ts");
    /* harmony import */


    var _services_cache_cache_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./services/cache/cache.service */
    "./src/app/services/cache/cache.service.ts");
    /* harmony import */


    var _services_notification_notification_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! ./services/notification/notification.service */
    "./src/app/services/notification/notification.service.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! ../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _services_network_network_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! ./services/network/network.service */
    "./src/app/services/network/network.service.ts");
    /* harmony import */


    var _shared_components_top_bar_top_bar_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! ./shared/components/top-bar/top-bar.component */
    "./src/app/shared/components/top-bar/top-bar.component.ts");
    /* harmony import */


    var _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! ./services/auth/auth.service */
    "./src/app/services/auth/auth.service.ts");

    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: AppModule,
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"]]
    });
    AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      factory: function AppModule_Factory(t) {
        return new (t || AppModule)();
      },
      providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_9__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_8__["SplashScreen"], {
        provide: _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouteReuseStrategy"],
        useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicRouteStrategy"]
      }, {
        provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HTTP_INTERCEPTORS"],
        useClass: _shared_interceptors_jwt_interceptor__WEBPACK_IMPORTED_MODULE_13__["JwtInterceptor"],
        multi: true
      }, {
        provide: _angular_core__WEBPACK_IMPORTED_MODULE_0__["APP_INITIALIZER"],
        useFactory: function useFactory(z, t, c, n, net, a) {
          return function () {
            net.init();
            c.init();
            z.init();
            t.init();
            n.init();
            a.init();
          };
        },
        deps: [_services_zoom_zoom_service__WEBPACK_IMPORTED_MODULE_15__["ZoomService"], _services_theme_theme_service__WEBPACK_IMPORTED_MODULE_16__["ThemeService"], _services_cache_cache_service__WEBPACK_IMPORTED_MODULE_17__["CacheService"], _services_notification_notification_service__WEBPACK_IMPORTED_MODULE_18__["NotificationService"], _services_network_network_service__WEBPACK_IMPORTED_MODULE_20__["NetworkService"], _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_22__["AuthService"]],
        multi: true
      }],
      imports: [[_angular_fire__WEBPACK_IMPORTED_MODULE_3__["AngularFireModule"].initializeApp(_environments_environment__WEBPACK_IMPORTED_MODULE_19__["environment"].firebase), _angular_fire_messaging__WEBPACK_IMPORTED_MODULE_4__["AngularFireMessagingModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__["BrowserAnimationsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_11__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClientModule"], _material_material_module__WEBPACK_IMPORTED_MODULE_12__["MaterialModule"], _angular_service_worker__WEBPACK_IMPORTED_MODULE_6__["ServiceWorkerModule"].register('ngsw-worker.js', {
        enabled: true
      }) //{ enabled: environment.production })
      ]]
    });

    (function () {
      (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppModule, {
        declarations: [_shared_components_top_bar_top_bar_component__WEBPACK_IMPORTED_MODULE_21__["TopBarComponent"], _app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"]],
        imports: [_angular_fire__WEBPACK_IMPORTED_MODULE_3__["AngularFireModule"], _angular_fire_messaging__WEBPACK_IMPORTED_MODULE_4__["AngularFireMessagingModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__["BrowserAnimationsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_11__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClientModule"], _material_material_module__WEBPACK_IMPORTED_MODULE_12__["MaterialModule"], _angular_service_worker__WEBPACK_IMPORTED_MODULE_6__["ServiceWorkerModule"]]
      });
    })();
    /*@__PURE__*/


    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
          imports: [_angular_fire__WEBPACK_IMPORTED_MODULE_3__["AngularFireModule"].initializeApp(_environments_environment__WEBPACK_IMPORTED_MODULE_19__["environment"].firebase), _angular_fire_messaging__WEBPACK_IMPORTED_MODULE_4__["AngularFireMessagingModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__["BrowserAnimationsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_11__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClientModule"], _material_material_module__WEBPACK_IMPORTED_MODULE_12__["MaterialModule"], _angular_service_worker__WEBPACK_IMPORTED_MODULE_6__["ServiceWorkerModule"].register('ngsw-worker.js', {
            enabled: true
          }) //{ enabled: environment.production })
          ],
          declarations: [_shared_components_top_bar_top_bar_component__WEBPACK_IMPORTED_MODULE_21__["TopBarComponent"], _app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"]],
          entryComponents: [],
          providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_9__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_8__["SplashScreen"], {
            provide: _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouteReuseStrategy"],
            useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicRouteStrategy"]
          }, {
            provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HTTP_INTERCEPTORS"],
            useClass: _shared_interceptors_jwt_interceptor__WEBPACK_IMPORTED_MODULE_13__["JwtInterceptor"],
            multi: true
          }, {
            provide: _angular_core__WEBPACK_IMPORTED_MODULE_0__["APP_INITIALIZER"],
            useFactory: function useFactory(z, t, c, n, net, a) {
              return function () {
                net.init();
                c.init();
                z.init();
                t.init();
                n.init();
                a.init();
              };
            },
            deps: [_services_zoom_zoom_service__WEBPACK_IMPORTED_MODULE_15__["ZoomService"], _services_theme_theme_service__WEBPACK_IMPORTED_MODULE_16__["ThemeService"], _services_cache_cache_service__WEBPACK_IMPORTED_MODULE_17__["CacheService"], _services_notification_notification_service__WEBPACK_IMPORTED_MODULE_18__["NotificationService"], _services_network_network_service__WEBPACK_IMPORTED_MODULE_20__["NetworkService"], _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_22__["AuthService"]],
            multi: true
          }],
          bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"]]
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/main/core/profile.ts":
  /*!**************************************!*\
    !*** ./src/app/main/core/profile.ts ***!
    \**************************************/

  /*! exports provided: Profile */

  /***/
  function srcAppMainCoreProfileTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Profile", function () {
      return Profile;
    });

    var Profile = /*#__PURE__*/function () {
      function Profile() {
        var values = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        _classCallCheck(this, Profile);

        Object.assign(this, values);
      }

      _createClass(Profile, [{
        key: "toString",
        value: function toString() {
          return JSON.stringify(this);
        }
      }]);

      return Profile;
    }();
    /***/

  },

  /***/
  "./src/app/material/material.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/material/material.module.ts ***!
    \*********************************************/

  /*! exports provided: MaterialModule */

  /***/
  function srcAppMaterialMaterialModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MaterialModule", function () {
      return MaterialModule;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/material/autocomplete */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/autocomplete.js");
    /* harmony import */


    var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/material/bottom-sheet */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/bottom-sheet.js");
    /* harmony import */


    var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/material/button */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
    /* harmony import */


    var _angular_material_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/material/card */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
    /* harmony import */


    var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/checkbox */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/checkbox.js");
    /* harmony import */


    var _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/chips */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/chips.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
    /* harmony import */


    var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/material/expansion */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/expansion.js");
    /* harmony import */


    var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @angular/material/form-field */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
    /* harmony import */


    var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @angular/material/grid-list */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/grid-list.js");
    /* harmony import */


    var _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @angular/material/icon */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
    /* harmony import */


    var _angular_material_input__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @angular/material/input */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
    /* harmony import */


    var _angular_material_list__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @angular/material/list */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/list.js");
    /* harmony import */


    var _angular_material_menu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @angular/material/menu */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/menu.js");
    /* harmony import */


    var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! @angular/material/progress-bar */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/progress-bar.js");
    /* harmony import */


    var _angular_material_select__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! @angular/material/select */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/select.js");
    /* harmony import */


    var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! @angular/material/sidenav */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/sidenav.js");
    /* harmony import */


    var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! @angular/material/slide-toggle */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/slide-toggle.js");
    /* harmony import */


    var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! @angular/material/snack-bar */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");
    /* harmony import */


    var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! @angular/material/stepper */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/stepper.js");
    /* harmony import */


    var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! @angular/material/tabs */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tabs.js");
    /* harmony import */


    var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! @angular/material/toolbar */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/toolbar.js");
    /* harmony import */


    var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
    /*! @angular/material/tooltip */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tooltip.js");
    /* harmony import */


    var _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
    /*! @angular/material/button-toggle */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button-toggle.js");

    var MaterialModule = function MaterialModule() {
      _classCallCheck(this, MaterialModule);
    };

    MaterialModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: MaterialModule
    });
    MaterialModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      factory: function MaterialModule_Factory(t) {
        return new (t || MaterialModule)();
      },
      providers: [_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__["MatSnackBar"]],
      imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_24__["MatTooltipModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_2__["MatAutocompleteModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButtonModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_6__["MatCheckboxModule"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__["MatChipsModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_14__["MatListModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_23__["MatToolbarModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_22__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_13__["MatInputModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatFormFieldModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_16__["MatProgressBarModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_21__["MatStepperModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_17__["MatSelectModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__["MatDialogModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_15__["MatMenuModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__["MatSidenavModule"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_19__["MatSlideToggleModule"], _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_25__["MatButtonToggleModule"]], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_24__["MatTooltipModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_2__["MatAutocompleteModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButtonModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_6__["MatCheckboxModule"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__["MatChipsModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_14__["MatListModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_23__["MatToolbarModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_22__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_13__["MatInputModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatFormFieldModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_16__["MatProgressBarModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_21__["MatStepperModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_17__["MatSelectModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__["MatDialogModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_15__["MatMenuModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__["MatSidenavModule"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_19__["MatSlideToggleModule"], _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_25__["MatButtonToggleModule"]]
    });

    (function () {
      (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](MaterialModule, {
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_24__["MatTooltipModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_2__["MatAutocompleteModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButtonModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_6__["MatCheckboxModule"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__["MatChipsModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_14__["MatListModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_23__["MatToolbarModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_22__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_13__["MatInputModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatFormFieldModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_16__["MatProgressBarModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_21__["MatStepperModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_17__["MatSelectModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__["MatDialogModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_15__["MatMenuModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__["MatSidenavModule"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_19__["MatSlideToggleModule"], _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_25__["MatButtonToggleModule"]],
        exports: [_angular_material_tooltip__WEBPACK_IMPORTED_MODULE_24__["MatTooltipModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_2__["MatAutocompleteModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButtonModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_6__["MatCheckboxModule"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__["MatChipsModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_14__["MatListModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_23__["MatToolbarModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_22__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_13__["MatInputModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatFormFieldModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_16__["MatProgressBarModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_21__["MatStepperModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_17__["MatSelectModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__["MatDialogModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_15__["MatMenuModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__["MatSidenavModule"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_19__["MatSlideToggleModule"], _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_25__["MatButtonToggleModule"]]
      });
    })();
    /*@__PURE__*/


    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MaterialModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
          declarations: [],
          imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_24__["MatTooltipModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_2__["MatAutocompleteModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButtonModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_6__["MatCheckboxModule"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__["MatChipsModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_14__["MatListModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_23__["MatToolbarModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_22__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_13__["MatInputModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatFormFieldModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_16__["MatProgressBarModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_21__["MatStepperModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_17__["MatSelectModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__["MatDialogModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_15__["MatMenuModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__["MatSidenavModule"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_19__["MatSlideToggleModule"], _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_25__["MatButtonToggleModule"]],
          providers: [_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__["MatSnackBar"]],
          exports: [_angular_material_tooltip__WEBPACK_IMPORTED_MODULE_24__["MatTooltipModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_2__["MatAutocompleteModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButtonModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_6__["MatCheckboxModule"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__["MatChipsModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_14__["MatListModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_23__["MatToolbarModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_22__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_13__["MatInputModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_20__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatFormFieldModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_16__["MatProgressBarModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_21__["MatStepperModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_17__["MatSelectModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_8__["MatDialogModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_15__["MatMenuModule"], _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_18__["MatSidenavModule"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_19__["MatSlideToggleModule"], _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_25__["MatButtonToggleModule"]]
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/api/api.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/api/api.service.ts ***!
    \*********************************************/

  /*! exports provided: ApiService */

  /***/
  function srcAppServicesApiApiServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ApiService", function () {
      return ApiService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/material/snack-bar */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _main_core_profile__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../main/core/profile */
    "./src/app/main/core/profile.ts");

    var API_URL = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].apiUrl;

    var ApiService = /*#__PURE__*/function () {
      function ApiService(http, errorToast) {
        _classCallCheck(this, ApiService);

        this.http = http;
        this.errorToast = errorToast;
      } // API: Sign Up User


      _createClass(ApiService, [{
        key: "signUp",
        value: function signUp(username, password, email) {
          var _this3 = this;

          return this.http.post("".concat(API_URL, "/register"), {
            username: username,
            password: password,
            email: email
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this3.handleError(error);
          }));
        } // API: Sign In User

      }, {
        key: "signIn",
        value: function signIn(username, password) {
          var _this4 = this;

          return this.http.post("".concat(API_URL, "/login"), {
            username: username,
            password: password
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this4.handleError(error);
          }));
        } // API: Send User Forgot Password Request

      }, {
        key: "forgotPassword",
        value: function forgotPassword(email) {
          var _this5 = this;

          return this.http.post("".concat(API_URL, "/forgot"), {
            email: email
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this5.handleError(error);
          }));
        } // API: Reset User Password

      }, {
        key: "resetPassword",
        value: function resetPassword(token, email, password, passwordConfirmation) {
          var _this6 = this;

          return this.http.post("".concat(API_URL, "/reset"), {
            token: token,
            email: email,
            password: password,
            password_confirmation: passwordConfirmation
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this6.handleError(error);
          }));
        } // API: Get User Profile

      }, {
        key: "getUser",
        value: function getUser() {
          var _this7 = this;

          return this.http.get("".concat(API_URL, "/me")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["publishReplay"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["refCount"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this7.handleError(error);
          }));
        } // API: Update User Profile

      }, {
        key: "updateUser",
        value: function updateUser(user) {
          var _this8 = this;

          // Fix for PHP not accepting files to PUT
          user instanceof FormData ? user.append('_method', 'PUT') : Object.assign(user, {
            _method: 'PUT'
          });
          return this.http.post("".concat(API_URL, "/me/update"), user).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this8.handleError(error);
          }));
        } // API: Register User Stripe Account

      }, {
        key: "registerStripe",
        value: function registerStripe(token) {
          var _this9 = this;

          return this.http.post("".concat(API_URL, "/me/stripe/register"), {
            token: token
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this9.handleError(error);
          }));
        } // API: Deactivate user profile

      }, {
        key: "deactivateProfile",
        value: function deactivateProfile() {
          var _this10 = this;

          return this.http.post("".concat(API_URL, "/me/deactivate"), null).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this10.handleError(error);
          }));
        } // API: Save FCM Token

      }, {
        key: "saveFcm",
        value: function saveFcm(token) {
          var _this11 = this;

          return this.http.post("".concat(API_URL, "/me/fcm/token"), {
            token: token
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this11.handleError(error);
          }));
        } // API: Delete FCM Token

      }, {
        key: "deleteFcm",
        value: function deleteFcm(token) {
          var _this12 = this;

          return this.http["delete"]("".concat(API_URL, "/me/fcm/token/").concat(token)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this12.handleError(error);
          }));
        } // API: Subscribe to FCM Topic

      }, {
        key: "subscribeFcm",
        value: function subscribeFcm(token, topic) {
          var _this13 = this;

          return this.http.post("".concat(API_URL, "/me/fcm/subscribe/").concat(topic), {
            token: token
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this13.handleError(error);
          }));
        } // API: Unsubcribe from FCM Topic

      }, {
        key: "unsubscribeFcm",
        value: function unsubscribeFcm(token, topic) {
          var _this14 = this;

          return this.http.post("".concat(API_URL, "/me/fcm/unsubscribe/").concat(topic), {
            token: token
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this14.handleError(error);
          }));
        } // API: Get user balance

      }, {
        key: "getUserBalance",
        value: function getUserBalance() {
          var _this15 = this;

          return this.http.get("".concat(API_URL, "/me/balance")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this15.handleError(error);
          }));
        } // API: Get user balance

      }, {
        key: "getUserDashboard",
        value: function getUserDashboard() {
          var _this16 = this;

          return this.http.get("".concat(API_URL, "/me/stripe/dashboard")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["publishReplay"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["refCount"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this16.handleError(error);
          }));
        } // API: Get user balance

      }, {
        key: "getCurrentUserStripe",
        value: function getCurrentUserStripe() {
          var _this17 = this;

          return this.http.get("".concat(API_URL, "/me/stripe/account")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["publishReplay"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["refCount"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this17.handleError(error);
          }));
        } // API: Get user transactions

      }, {
        key: "getUserTransactions",
        value: function getUserTransactions() {
          var _this18 = this;

          return this.http.get("".concat(API_URL, "/transaction")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this18.handleError(error);
          }));
        } // API: Get user sources

      }, {
        key: "getUserSources",
        value: function getUserSources() {
          var _this19 = this;

          return this.http.get("".concat(API_URL, "/me/payment/source")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this19.handleError(error);
          }));
        } // API: Get user source

      }, {
        key: "getUserSource",
        value: function getUserSource(method) {
          var _this20 = this;

          return this.http.get("".concat(API_URL, "/me/payment/source/").concat(method)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this20.handleError(error);
          }));
        } // API: Save user source

      }, {
        key: "saveUserSource",
        value: function saveUserSource(source) {
          var _this21 = this;

          return this.http.post("".concat(API_URL, "/me/payment/source"), source, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this21.handleError(error);
          }));
        } // API: Delete user source

      }, {
        key: "deleteUserSource",
        value: function deleteUserSource(method) {
          var _this22 = this;

          return this.http["delete"]("".concat(API_URL, "/me/payment/source/").concat(method), {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this22.handleError(error);
          }));
        } // API: Get PaymentIntent

      }, {
        key: "getIntent",
        value: function getIntent(for_user_id, nonce) {
          var _this23 = this;

          return this.http.get("".concat(API_URL, "/transaction/prepare?for_user_id=").concat(for_user_id, "&nonce=").concat(nonce)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this23.handleError(error);
          }));
        } // API: Update PaymentIntent

      }, {
        key: "updateIntent",
        value: function updateIntent(stripe_transaction_id, amount, currency, description) {
          var _this24 = this;

          return this.http.put("".concat(API_URL, "/transaction/update"), {
            stripe_transaction_id: stripe_transaction_id,
            amount: amount,
            currency: currency,
            description: description
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this24.handleError(error);
          }));
        } // API: Confirm Payment

      }, {
        key: "confirmPayment",
        value: function confirmPayment(payload) {
          var _this25 = this;

          return this.http.post("".concat(API_URL, "/transaction/pay"), payload, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this25.handleError(error);
          }));
        } // API: Get Profile

      }, {
        key: "getProfile",
        value: function getProfile(id) {
          var _this26 = this;

          return this.http.get("".concat(API_URL, "/profile/").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["publishReplay"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["refCount"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this26.handleError(error);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (profile) {
            return new _main_core_profile__WEBPACK_IMPORTED_MODULE_6__["Profile"](profile);
          }));
        } // API: Get Stripe Profile

      }, {
        key: "getStripeProfile",
        value: function getStripeProfile(id) {
          var _this27 = this;

          return this.http.get("".concat(API_URL, "/profile/stripe/").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["publishReplay"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["refCount"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this27.handleError(error);
          }));
        } // API: List User Withdrawls

      }, {
        key: "getStripeWithdrawls",
        value: function getStripeWithdrawls() {
          var _this28 = this;

          return this.http.get("".concat(API_URL, "/me/withdrawl")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this28.handleError(error);
          }));
        } // API: Withdraw Stripe balance

      }, {
        key: "withdrawStripeBalance",
        value: function withdrawStripeBalance(amount, currency) {
          var _this29 = this;

          return this.http.post("".concat(API_URL, "/me/withdrawl"), {
            amount: amount,
            currency: currency
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this29.handleError(error);
          }));
        } // API: User Search

      }, {
        key: "search",
        value: function search(query) {
          var _this30 = this;

          var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
          return this.http.get("".concat(API_URL, "/search"), {
            params: {
              query: query,
              type: type
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this30.handleError(error);
          }));
        } // API: Update exchange rates

      }, {
        key: "updateRates",
        value: function updateRates() {
          var _this31 = this;

          return this.http.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].fx.url, {
            params: {
              app_id: _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].fx.client_id
            }
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (error) {
            return _this31.handleError(error);
          }));
        } // Success handling

      }, {
        key: "handleSuccess",
        value: function handleSuccess(message) {
          // Open snackbar
          this.errorToast.open(message, 'close', {
            duration: 3000
          });
        } // Error handling

      }, {
        key: "handleError",
        value: function handleError(error) {
          var errorMessage;
          console.warn(error); // Set error message

          if (!!error.error.error) errorMessage = "".concat(error.error.error); // else if (!!error.error) errorMessage = `(${error.status}) Message: ${error.error}`;
          else errorMessage = "(".concat(error.status, ") Message: ").concat(error.statusText); // Open error snackbar

          this.errorToast.open(errorMessage, 'close', {
            duration: 3000
          });
          return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(errorMessage);
        }
      }]);

      return ApiService;
    }();

    ApiService.ɵfac = function ApiService_Factory(t) {
      return new (t || ApiService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__["MatSnackBar"]));
    };

    ApiService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: ApiService,
      factory: ApiService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ApiService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
        }, {
          type: _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__["MatSnackBar"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/auth/auth.service.ts":
  /*!***********************************************!*\
    !*** ./src/app/services/auth/auth.service.ts ***!
    \***********************************************/

  /*! exports provided: AuthService */

  /***/
  function srcAppServicesAuthAuthServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthService", function () {
      return AuthService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _user_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../user/user.service */
    "./src/app/services/user/user.service.ts");
    /* harmony import */


    var _cache_cache_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../cache/cache.service */
    "./src/app/services/cache/cache.service.ts");
    /* harmony import */


    var _backend_backend_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../backend/backend.service */
    "./src/app/services/backend/backend.service.ts");

    var AuthService = /*#__PURE__*/function () {
      function AuthService(user, router, cache, backend) {
        _classCallCheck(this, AuthService);

        this.user = user;
        this.router = router;
        this.cache = cache;
        this.backend = backend;
        this.loggedIn = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](false);
      }

      _createClass(AuthService, [{
        key: "init",
        value: function init() {
          var _this32 = this;

          // On logged in status change update user TODO: Check this works
          this.loggedIn.pipe( // Only proceed on logged in true
          Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["filter"])(function (l) {
            return !!l;
          }), // Update user profile
          Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function () {
            return _this32.updateProfile();
          })).subscribe();
          console.log('Attempting to load user'); // On initial load attempt loading user

          this.user.loadCache().subscribe(function (u) {
            return _this32.loggedIn.next(!!u);
          });
        }
      }, {
        key: "isLoggedIn",
        value: function isLoggedIn() {
          return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(!!this.user.token).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["distinctUntilChanged"])());
        }
      }, {
        key: "hasSession",
        value: function hasSession() {
          return this.cache.get('login').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (u) {
            return console.log('User has session', u);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (u) {
            return !!u;
          }));
        }
      }, {
        key: "doSignIn",
        value: function doSignIn(response, passphrase) {
          // TODO: This function should call the API and proceed with response
          this.user.build(response, passphrase);
          this.loggedIn.next(true);
        }
      }, {
        key: "authorize",
        value: function authorize(passphrase) {
          var _this33 = this;

          console.log('Decode user with passphrase', passphrase);
          return this.cache.get('login', passphrase).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (user) {
            return console.log('Attempting to save user:', user);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["mergeMap"])(function (user) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["iif"])(function () {
              return !!user.token;
            }, Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(true).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
              return console.log('User exists, updating service');
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
              return Object.assign(_this33.user, user);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
              return console.log('Service updated, fetching from backend');
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["mergeMap"])(function () {
              return _this33.updateProfile();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
              return console.log('Service updated', _this33.user);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
              return _this33.loggedIn.next(true);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function () {
              return true;
            })), Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(false));
          }));
        }
      }, {
        key: "updateProfile",
        value: function updateProfile() {
          var _this34 = this;

          console.log('Updating profile');
          return this.backend.getUser().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (profile) {
            return Object.assign(_this34.user.profile, profile);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (u) {
            return _this34.user.profile$.next(u);
          }));
        }
      }, {
        key: "doSignOut",
        value: function doSignOut() {
          this.cache.clear();
          this.loggedIn.next(false);
          this.router.navigate(['/login']);
          this.user.destroy();
        }
      }, {
        key: "getToken",
        value: function getToken() {
          return this.user.token || null;
        }
      }]);

      return AuthService;
    }();

    AuthService.ɵfac = function AuthService_Factory(t) {
      return new (t || AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_user_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_cache_cache_service__WEBPACK_IMPORTED_MODULE_5__["CacheService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_backend_backend_service__WEBPACK_IMPORTED_MODULE_6__["BackendService"]));
    };

    AuthService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: AuthService,
      factory: AuthService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AuthService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _user_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }, {
          type: _cache_cache_service__WEBPACK_IMPORTED_MODULE_5__["CacheService"]
        }, {
          type: _backend_backend_service__WEBPACK_IMPORTED_MODULE_6__["BackendService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/backend/backend.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/services/backend/backend.service.ts ***!
    \*****************************************************/

  /*! exports provided: BackendService */

  /***/
  function srcAppServicesBackendBackendServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BackendService", function () {
      return BackendService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../api/api.service */
    "./src/app/services/api/api.service.ts");
    /* harmony import */


    var _cache_cache_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../cache/cache.service */
    "./src/app/services/cache/cache.service.ts");

    var BackendService = /*#__PURE__*/function () {
      function BackendService(api, cache) {
        _classCallCheck(this, BackendService);

        this.api = api;
        this.cache = cache;
      } // Sign Up User


      _createClass(BackendService, [{
        key: "signUp",
        value: function signUp(username, password, email) {
          return this.api.signUp(username, password, email);
        } // Sign In User

      }, {
        key: "signIn",
        value: function signIn(username, password) {
          return this.api.signIn(username, password);
        } // Send User Forgot Password Request

      }, {
        key: "forgotPassword",
        value: function forgotPassword(email) {
          return this.api.forgotPassword(email);
        } // Reset User Password

      }, {
        key: "resetPassword",
        value: function resetPassword(token, email, password, passwordConfirmation) {
          return this.api.resetPassword(token, email, password, passwordConfirmation);
        } // Get User Profile

      }, {
        key: "getUser",
        value: function getUser() {
          return this.api.getUser();
        } // Get user balance

      }, {
        key: "getUserBalance",
        value: function getUserBalance() {
          return this.api.getUserBalance();
        } // Get user balance

      }, {
        key: "getUserDashboard",
        value: function getUserDashboard() {
          return this.api.getUserDashboard();
        } // Get user balance

      }, {
        key: "getCurrentUserStripe",
        value: function getCurrentUserStripe() {
          return this.api.getCurrentUserStripe();
        } // Get user transactions

      }, {
        key: "getUserTransaction",
        value: function getUserTransaction() {
          return this.api.getUserTransactions();
        } // Get user sources

      }, {
        key: "getUserSources",
        value: function getUserSources() {
          return this.api.getUserSources();
        } // Get user source

      }, {
        key: "getUserSource",
        value: function getUserSource(method) {
          return this.api.getUserSource(method);
        } // Save user source

      }, {
        key: "saveUserSource",
        value: function saveUserSource(source) {
          return this.api.saveUserSource(source);
        } // Save user source

      }, {
        key: "deleteUserSource",
        value: function deleteUserSource(method) {
          return this.api.deleteUserSource(method);
        } // Update User Profile

      }, {
        key: "updateUser",
        value: function updateUser(user) {
          return this.api.updateUser(user);
        } // Register User Stripe Account

      }, {
        key: "registerStripe",
        value: function registerStripe(token) {
          return this.api.registerStripe(token);
        } // Deactivate user profile

      }, {
        key: "deactivateProfile",
        value: function deactivateProfile() {
          return this.api.deactivateProfile();
        } // Save FCM Token

      }, {
        key: "saveFcm",
        value: function saveFcm(token) {
          return this.api.saveFcm(token);
        } // Delete FCM Token

      }, {
        key: "deleteFcm",
        value: function deleteFcm(token) {
          return this.api.deleteFcm(token);
        } // Subscribe to FCM Topic

      }, {
        key: "subscribeFcm",
        value: function subscribeFcm(token, topic) {
          return this.api.subscribeFcm(token, topic);
        } // Unsubcribe from FCM Topic

      }, {
        key: "unsubscribeFcm",
        value: function unsubscribeFcm(token, topic) {
          return this.api.unsubscribeFcm(token, topic);
        } // Get Profile

      }, {
        key: "getProfile",
        value: function getProfile(id) {
          var _this35 = this;

          return this.api.getProfile(id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])(function (error) {
            // Return from localStorage
            return _this35.cache.get("profile-".concat(id));
          }));
        } // Get Stripe Profile

      }, {
        key: "getStripeProfile",
        value: function getStripeProfile(id) {
          return this.api.getStripeProfile(id);
        } // Get PaymentIntent

      }, {
        key: "getIntent",
        value: function getIntent(for_user_id, nonce) {
          return this.api.getIntent(for_user_id, nonce);
        } // Get PaymentIntent

      }, {
        key: "updateIntent",
        value: function updateIntent(stripe_transaction_id, amount, currency, description) {
          return this.api.updateIntent(stripe_transaction_id, amount, currency, description);
        } // Confirm Payment

      }, {
        key: "confirmPayment",
        value: function confirmPayment(payload) {
          return this.api.confirmPayment(payload);
        } // List User Withdrawls

      }, {
        key: "getStripeWithdrawls",
        value: function getStripeWithdrawls() {
          return this.api.getStripeWithdrawls();
        } // Withdraw Stripe balance

      }, {
        key: "withdrawStripeBalance",
        value: function withdrawStripeBalance(amount, currency) {
          return this.api.withdrawStripeBalance(amount, currency);
        } // User Search

      }, {
        key: "search",
        value: function search(query, type) {
          return this.api.search(query, type);
        } // Update exchange rate

      }, {
        key: "updateRates",
        value: function updateRates() {
          return this.api.updateRates();
        }
      }]);

      return BackendService;
    }();

    BackendService.ɵfac = function BackendService_Factory(t) {
      return new (t || BackendService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_cache_cache_service__WEBPACK_IMPORTED_MODULE_3__["CacheService"]));
    };

    BackendService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: BackendService,
      factory: BackendService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BackendService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _cache_cache_service__WEBPACK_IMPORTED_MODULE_3__["CacheService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/cache/cache.service.ts":
  /*!*************************************************!*\
    !*** ./src/app/services/cache/cache.service.ts ***!
    \*************************************************/

  /*! exports provided: CacheService */

  /***/
  function srcAppServicesCacheCacheServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CacheService", function () {
      return CacheService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var localforage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! localforage */
    "./node_modules/localforage/dist/localforage.js");
    /* harmony import */


    var localforage__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(localforage__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! crypto-js */
    "./node_modules/crypto-js/index.js");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var CacheService = /*#__PURE__*/function () {
      function CacheService() {
        _classCallCheck(this, CacheService);
      }

      _createClass(CacheService, [{
        key: "init",
        // Init Cache
        value: function init() {
          console.log('Configuring Cache', src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].cache); // Configure local storage

          return localforage__WEBPACK_IMPORTED_MODULE_2__["config"](src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].cache);
        } // Store item

      }, {
        key: "store",
        value: function store(key, data, passphrase) {
          var ciphertext; // If passphrase exists, encrypt data

          if (passphrase) {
            console.log('Store', JSON.stringify(data), '\nKey', passphrase);
            ciphertext = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(JSON.stringify(data), passphrase).toString();
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["from"])(localforage__WEBPACK_IMPORTED_MODULE_2__["setItem"](key, ciphertext));
          } // If passphrase store encrypted text, else store JSON string


          return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["from"])(localforage__WEBPACK_IMPORTED_MODULE_2__["setItem"](key, data));
        } // Get item

      }, {
        key: "get",
        value: function get(key, passphrase) {
          console.log("Retrieving ".concat(key, " from cache"));
          return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["from"])(localforage__WEBPACK_IMPORTED_MODULE_2__["getItem"](key)).pipe( // Switch passphrase present
          Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["mergeMap"])(function (data) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["iif"])(function () {
              return !!passphrase;
            }, // Decode data
            Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(true).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function () {
              return JSON.parse(crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(data, passphrase).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8));
            })), // Return data
            Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(data));
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) {
            console.warn(err);
            return null;
          }));
        } // Delete item

      }, {
        key: "delete",
        value: function _delete(key) {
          return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["from"])(localforage__WEBPACK_IMPORTED_MODULE_2__["removeItem"](key));
        } // Clear cache

      }, {
        key: "clear",
        value: function clear() {
          return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["from"])(localforage__WEBPACK_IMPORTED_MODULE_2__["clear"]());
        }
      }]);

      return CacheService;
    }();

    CacheService.ɵfac = function CacheService_Factory(t) {
      return new (t || CacheService)();
    };

    CacheService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: CacheService,
      factory: CacheService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CacheService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/ipc/ipc.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/ipc/ipc.service.ts ***!
    \*********************************************/

  /*! exports provided: IpcService */

  /***/
  function srcAppServicesIpcIpcServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IpcService", function () {
      return IpcService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var IpcService = /*#__PURE__*/function () {
      function IpcService() {
        _classCallCheck(this, IpcService);

        console.log('Init IPC Service');

        if (window.require) {
          try {
            this.ipc = window.require('electron').ipcRenderer; // TODO: Confirm functioning

            console.log(this.ipc);
          } catch (e) {
            throw e;
          }
        } else {
          console.warn('Electron\'s IPC was not loaded');
        }
      }

      _createClass(IpcService, [{
        key: "on",
        value: function on(channel, listener) {
          if (!this.ipc) {
            return;
          }

          this.ipc.on(channel, listener);
        }
      }, {
        key: "send",
        value: function send(channel) {
          var _this$ipc;

          if (!this.ipc) {
            return;
          }

          for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
            args[_key - 1] = arguments[_key];
          }

          (_this$ipc = this.ipc).send.apply(_this$ipc, [channel].concat(args));
        }
      }]);

      return IpcService;
    }();

    IpcService.ɵfac = function IpcService_Factory(t) {
      return new (t || IpcService)();
    };

    IpcService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: IpcService,
      factory: IpcService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IpcService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/network/network.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/services/network/network.service.ts ***!
    \*****************************************************/

  /*! exports provided: NetworkService */

  /***/
  function srcAppServicesNetworkNetworkServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NetworkService", function () {
      return NetworkService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");

    var _capacitor_core__WEBP = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"],
        Network = _capacitor_core__WEBP.Network,
        Modals = _capacitor_core__WEBP.Modals;

    var NetworkService = /*#__PURE__*/function () {
      function NetworkService() {
        _classCallCheck(this, NetworkService);
      }

      _createClass(NetworkService, [{
        key: "init",
        value: function init() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    // Initial network check
                    this.alertStatusNeeded(); // Subscribe to change events for checking

                    Network.addListener('networkStatusChange', this.alertStatusNeeded);

                  case 2:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "alertStatusNeeded",
        value: function alertStatusNeeded() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var connected;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return Network.getStatus().then(function (n) {
                      return n.connected;
                    });

                  case 2:
                    connected = _context2.sent;

                    if (connected) {
                      _context2.next = 6;
                      break;
                    }

                    _context2.next = 6;
                    return Modals.alert({
                      title: 'Network Needed',
                      message: 'A network connection is needed to use Flow, please enable Wi-Fi or data.'
                    });

                  case 6:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2);
          }));
        }
      }]);

      return NetworkService;
    }();

    NetworkService.ɵfac = function NetworkService_Factory(t) {
      return new (t || NetworkService)();
    };

    NetworkService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
      token: NetworkService,
      factory: NetworkService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](NetworkService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/notification/notification.service.ts":
  /*!***************************************************************!*\
    !*** ./src/app/services/notification/notification.service.ts ***!
    \***************************************************************/

  /*! exports provided: NotificationService */

  /***/
  function srcAppServicesNotificationNotificationServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NotificationService", function () {
      return NotificationService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _push_push_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ../push/push.service */
    "./src/app/services/push/push.service.ts");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../auth/auth.service */
    "./src/app/services/auth/auth.service.ts");
    /* harmony import */


    var _backend_backend_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../backend/backend.service */
    "./src/app/services/backend/backend.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var NotificationService = /*#__PURE__*/function () {
      // DEBUG: Fix backend save token and subscribe topic
      function NotificationService(push, auth, backend) {
        var _this36 = this;

        _classCallCheck(this, NotificationService);

        this.push = push;
        this.auth = auth;
        this.backend = backend; // On new token, if token has value and user is logged in, save

        push.token.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (token) {
          return console.log("New FCM token ".concat(token));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["filter"])(function (token) {
          return !!token;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["filter"])(function () {
          return auth.loggedIn.value;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["mergeMap"])(function (token) {
          return _this36.saveToken(token);
        })).subscribe(); // On new login status, update token status

        auth.loggedIn.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (l) {
          return console.log("User Login Status Changed to ".concat(l));
        }), // If token has no value we can't proceed
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["filter"])(function () {
          return !!push.token.value;
        }), // Merge to backend call
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["mergeMap"])(function (l) {
          return l ? _this36.saveToken(push.token.value) : _this36.deleteToken(push.token.value);
        })).subscribe();
      } // Init push services


      _createClass(NotificationService, [{
        key: "init",
        value: function init() {
          return this.push.init();
        } // Send to server to save token

      }, {
        key: "saveToken",
        value: function saveToken(token) {
          console.log("Saving Token: ".concat(token)); // Send token to server

          return this.backend.saveFcm(token).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            return console.log("Saved FCM ".concat(token));
          }));
        } // Send to server to delete token

      }, {
        key: "deleteToken",
        value: function deleteToken(token) {
          console.log("Unsaving Token: ".concat(token)); // Send token to server

          return this.backend.deleteFcm(token).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            return console.log("Deleted FCM ".concat(token));
          }));
        } // Send to server to subscribe

      }, {
        key: "subscribe",
        value: function subscribe(topic, token) {
          console.log("Subscribing topic: ".concat(topic));
          return this.backend.subscribeFcm(token, topic).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(console.log));
        } // Send to server to unsubscribe

      }, {
        key: "unsubscribe",
        value: function unsubscribe(topic, token) {
          console.log("Unsubscribing topic: ".concat(topic));
          return this.backend.subscribeFcm(token, topic).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(console.log));
        }
      }]);

      return NotificationService;
    }();

    NotificationService.ɵfac = function NotificationService_Factory(t) {
      return new (t || NotificationService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_push_push_service__WEBPACK_IMPORTED_MODULE_1__["PushService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_backend_backend_service__WEBPACK_IMPORTED_MODULE_3__["BackendService"]));
    };

    NotificationService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: NotificationService,
      factory: NotificationService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NotificationService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _push_push_service__WEBPACK_IMPORTED_MODULE_1__["PushService"]
        }, {
          type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
        }, {
          type: _backend_backend_service__WEBPACK_IMPORTED_MODULE_3__["BackendService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/push/push.service.ts":
  /*!***********************************************!*\
    !*** ./src/app/services/push/push.service.ts ***!
    \***********************************************/

  /*! exports provided: PushService */

  /***/
  function srcAppServicesPushPushServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PushService", function () {
      return PushService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_fire_messaging__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/fire/messaging */
    "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-messaging.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _ipc_ipc_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../ipc/ipc.service */
    "./src/app/services/ipc/ipc.service.ts");
    /* harmony import */


    var electron_push_receiver_src_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! electron-push-receiver/src/constants */
    "./node_modules/electron-push-receiver/src/constants/index.js");
    /* harmony import */


    var electron_push_receiver_src_constants__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(electron_push_receiver_src_constants__WEBPACK_IMPORTED_MODULE_7__);
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var _capacitor_core__WEBP2 = _capacitor_core__WEBPACK_IMPORTED_MODULE_3__["Plugins"],
        PushNotifications = _capacitor_core__WEBP2.PushNotifications,
        Device = _capacitor_core__WEBP2.Device;

    var PushService = /*#__PURE__*/function () {
      function PushService(ipc, platform, fire) {
        _classCallCheck(this, PushService);

        this.ipc = ipc;
        this.platform = platform;
        this.fire = fire;
        this.token = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]('');
      }

      _createClass(PushService, [{
        key: "init",
        value: function init() {
          console.log('Running FCM init'); // DEBUG: Log device

          Device.getInfo().then(function (i) {
            return console.log(JSON.stringify(i, null, '\t'));
          }); // Check device

          if (this.platform.is('electron')) {
            // Setup for Electron
            this.electronInit();
          } else if (this.platform.is('hybrid')) {
            // Setup for mobile
            this.defaultInit();
          } else {
            // Setup for browser/PWA
            this.browserInit();
          }
        } // Default Non-Electron Init

      }, {
        key: "defaultInit",
        value: function defaultInit() {
          var _this37 = this;

          // Register with Apple / Google to receive push via APNS/FCM
          PushNotifications.register(); // On success, we should be able to receive notifications

          PushNotifications.addListener('registration', function (token) {
            console.log("FCM Registered ".concat(JSON.stringify(token, null, '\t')));

            _this37.token.next(token.value);
          }); // Some issue with our setup and push will not work

          PushNotifications.addListener('registrationError', function (error) {
            console.warn("FCM Error ".concat(JSON.stringify(error, null, '\t')));
          }); // Show us the notification payload if the app is open on our device

          PushNotifications.addListener('pushNotificationReceived', function (notification) {
            console.log("FCM Notification ".concat(JSON.stringify(notification, null, '\t')));
          }); // Method called when tapping on a notification

          PushNotifications.addListener('pushNotificationActionPerformed', function (notification) {
            console.log("Push action ".concat(JSON.stringify(notification, null, '\t')));
          });
        } // Register push for browser

      }, {
        key: "browserInit",
        value: function browserInit() {
          var _this38 = this;

          console.log('Called FCM browser init'); // Handle no service worker

          var noSw = setTimeout(function () {
            return _this38.browserRegisterSw();
          }, 5 * 1000); // Wait for service worker to be ready

          navigator.serviceWorker.ready.then(function (registration) {
            clearTimeout(noSw);
            noSw = null;

            _this38.browserMessagingRegistration(registration);
          });
        }
      }, {
        key: "browserRegisterSw",
        value: function browserRegisterSw() {
          console.warn('No active service worker found, not able to get firebase messaging');
          navigator.serviceWorker.register('firebase-messaging-sw.js');
        }
      }, {
        key: "browserMessagingRegistration",
        value: function browserMessagingRegistration(registration, token) {
          var _this39 = this;

          console.log('FCM Registration:', registration);
          this.fire.requestPermission.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["mergeMapTo"])(this.fire.tokenChanges), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["tap"])(console.log)).subscribe(function (token) {
            console.log('FCM Permission Granted:', token); // Subscribe to FCM tokens

            _this39.token.next(token); // Subscribe to notifications


            _this39.fire.messages.subscribe(console.log);
          }, console.error);
        } // Register push for electron

      }, {
        key: "electronInit",
        value: function electronInit() {
          var _this40 = this;

          // Handle push registration
          this.ipc.on(electron_push_receiver_src_constants__WEBPACK_IMPORTED_MODULE_7__["NOTIFICATION_SERVICE_STARTED"], function (_, token) {
            console.log('Push service successfully started', token);

            _this40.token.next(token);
          }); // Handle push errors

          this.ipc.on(electron_push_receiver_src_constants__WEBPACK_IMPORTED_MODULE_7__["NOTIFICATION_SERVICE_ERROR"], function (_, error) {
            console.warn('Push notification error', error);
          }); // Send token to backend when updated

          this.ipc.on(electron_push_receiver_src_constants__WEBPACK_IMPORTED_MODULE_7__["TOKEN_UPDATED"], function (_, token) {
            console.log('Push token updated', token);

            _this40.token.next(token);
          }); // Display notification

          this.ipc.on(electron_push_receiver_src_constants__WEBPACK_IMPORTED_MODULE_7__["NOTIFICATION_RECEIVED"], function (_, fcmNotification) {
            // DEBUG: Log notification
            console.log('Notification', fcmNotification); // Check notification for display title

            if (fcmNotification.notification.title || fcmNotification.notification.body) {
              Notification.requestPermission().then(function (p) {
                if (p !== 'granted') {
                  return;
                }

                var notification = new Notification(fcmNotification.notification.title, {
                  body: fcmNotification.notification.body || '',
                  icon: fcmNotification.notification.icon || 'assets/icons/icon-128x128.png'
                });

                notification.onclick = function () {
                  console.log('Notification clicked');
                };
              });
              return;
            } // Payload has no body, so consider it silent (just consider the data portion)

          }); // Start service

          console.log('Starting Electron push');
          this.ipc.send(electron_push_receiver_src_constants__WEBPACK_IMPORTED_MODULE_7__["START_NOTIFICATION_SERVICE"], _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].firebase.messagingSenderId);
        }
      }]);

      return PushService;
    }();

    PushService.ɵfac = function PushService_Factory(t) {
      return new (t || PushService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_ipc_ipc_service__WEBPACK_IMPORTED_MODULE_6__["IpcService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_fire_messaging__WEBPACK_IMPORTED_MODULE_1__["AngularFireMessaging"]));
    };

    PushService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: PushService,
      factory: PushService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PushService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _ipc_ipc_service__WEBPACK_IMPORTED_MODULE_6__["IpcService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
        }, {
          type: _angular_fire_messaging__WEBPACK_IMPORTED_MODULE_1__["AngularFireMessaging"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/theme/theme.service.ts":
  /*!*************************************************!*\
    !*** ./src/app/services/theme/theme.service.ts ***!
    \*************************************************/

  /*! exports provided: ThemeService */

  /***/
  function srcAppServicesThemeThemeServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ThemeService", function () {
      return ThemeService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _cache_cache_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../cache/cache.service */
    "./src/app/services/cache/cache.service.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var ThemeService = /*#__PURE__*/function () {
      function ThemeService(_cache) {
        _classCallCheck(this, ThemeService);

        this._cache = _cache;
        this.domBody = document.body;
        this.darkMode = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](false);
      }

      _createClass(ThemeService, [{
        key: "init",
        value: function init() {
          var _this41 = this;

          // Set dark theme from cache
          this._cache.get('dark-theme').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (d) {
            return _this41.toggleDarkMode(!!d);
          })).subscribe(function (d) {
            return _this41.darkMode.next(!!d);
          }); // Set colour theme from cache


          this._cache.get('colour-theme').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (d) {
            return d ? d : _this41.defaultTheme();
          })).subscribe(function (t) {
            return _this41.setColourTheme(t);
          });
        } // Return is dark observable

      }, {
        key: "isDarkMode",
        value: function isDarkMode() {
          return this.darkMode.asObservable();
        } // Set dark mode to value

      }, {
        key: "toggleDarkMode",
        value: function toggleDarkMode(enable) {
          !!enable ? this.domBody.classList.add('dark-theme') : this.domBody.classList.remove('dark-theme');
          this.darkMode.next(!!enable);

          this._cache.store('dark-theme', enable);
        } // Return list of available themes

      }, {
        key: "availableThemes",
        value: function availableThemes() {
          return Object.keys(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].themes);
        } // Return default theme

      }, {
        key: "defaultTheme",
        value: function defaultTheme() {
          return Object.keys(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].themes).find(function (key) {
            return _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].themes[key] == '';
          });
        } // Return current theme

      }, {
        key: "currentTheme",
        value: function currentTheme() {
          var _this42 = this;

          var current = Object.keys(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"]).find(function (t) {
            return _this42.domBody.classList.contains(t);
          });

          if (current) {
            return current;
          }

          return this.defaultTheme();
        } // Set theme to value

      }, {
        key: "setColourTheme",
        value: function setColourTheme(theme) {
          var _this43 = this;

          // Check theme exists
          if (!Object.keys(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"]).includes(theme)) {
            return;
          } // Add new theme to body


          this.domBody.classList.add(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].themes[theme]); // Remove old theme

          Object.entries(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].themes).filter(function (_ref) {
            var _ref2 = _slicedToArray(_ref, 2),
                key = _ref2[0],
                value = _ref2[1];

            return key != theme;
          }).forEach(function (_ref3) {
            var _ref4 = _slicedToArray(_ref3, 2),
                key = _ref4[0],
                value = _ref4[1];

            return _this43.domBody.classList.remove(value);
          });
        }
      }]);

      return ThemeService;
    }();

    ThemeService.ɵfac = function ThemeService_Factory(t) {
      return new (t || ThemeService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_cache_cache_service__WEBPACK_IMPORTED_MODULE_2__["CacheService"]));
    };

    ThemeService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: ThemeService,
      factory: ThemeService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ThemeService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _cache_cache_service__WEBPACK_IMPORTED_MODULE_2__["CacheService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/user/user.service.ts":
  /*!***********************************************!*\
    !*** ./src/app/services/user/user.service.ts ***!
    \***********************************************/

  /*! exports provided: UserService */

  /***/
  function srcAppServicesUserUserServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserService", function () {
      return UserService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _main_core_profile__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../main/core/profile */
    "./src/app/main/core/profile.ts");
    /* harmony import */


    var _cache_cache_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../cache/cache.service */
    "./src/app/services/cache/cache.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var UserService = /*#__PURE__*/function () {
      function UserService(cache) {
        _classCallCheck(this, UserService);

        this.cache = cache;
        this.profile = new _main_core_profile__WEBPACK_IMPORTED_MODULE_2__["Profile"]();
        this.profile$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](new _main_core_profile__WEBPACK_IMPORTED_MODULE_2__["Profile"]());
      } // Load user from cache


      _createClass(UserService, [{
        key: "loadCache",
        value: function loadCache() {
          var _this44 = this;

          console.log('Attempting to load user');
          return this.cache.get('login').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["filter"])(function (u) {
            return !!u && u.token;
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (user) {
            return Object.assign(_this44, user);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function () {
            return true;
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (err) {
            console.warn(err);
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(false);
          }));
        } // Build user object

      }, {
        key: "build",
        value: function build(model, passphrase) {
          console.log('Building user service', model);

          try {
            // Update user as logged in
            Object.assign(this, model);
            this.profile$.next(this.profile); // Cache user object

            this.cacheUser(passphrase).subscribe();
            console.log('Built user service', this.toJson());
          } catch (e) {
            throw e;
          }
        } // Destroy local user

      }, {
        key: "destroy",
        value: function destroy() {
          this.token = null;
          this.profile = null;
        } // Save user object

      }, {
        key: "cacheUser",
        value: function cacheUser(passphrase) {
          return this.cache.store('login', this.toJson(), passphrase);
        }
      }, {
        key: "toJson",
        value: function toJson() {
          return {
            token: this.token,
            profile: {
              id: this.profile.id,
              stripeConnectId: this.profile.stripeConnectId,
              stripeCustomerId: this.profile.stripeCustomerId
            }
          };
        }
      }]);

      return UserService;
    }();

    UserService.ɵfac = function UserService_Factory(t) {
      return new (t || UserService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_cache_cache_service__WEBPACK_IMPORTED_MODULE_3__["CacheService"]));
    };

    UserService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: UserService,
      factory: UserService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](UserService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _cache_cache_service__WEBPACK_IMPORTED_MODULE_3__["CacheService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/services/zoom/zoom.service.ts":
  /*!***********************************************!*\
    !*** ./src/app/services/zoom/zoom.service.ts ***!
    \***********************************************/

  /*! exports provided: ZoomService */

  /***/
  function srcAppServicesZoomZoomServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ZoomService", function () {
      return ZoomService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _cache_cache_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../cache/cache.service */
    "./src/app/services/cache/cache.service.ts");

    var ZoomService = /*#__PURE__*/function () {
      function ZoomService(_cache) {
        _classCallCheck(this, ZoomService);

        this._cache = _cache; // Get zoom level (localStorage required for electron index.js)

        this.zoom$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](100);
      }

      _createClass(ZoomService, [{
        key: "init",
        value: function init() {
          var _this45 = this;

          console.log('Init Zoom Service'); // Set doZoom recipe

          this.doZoom$ = this.zoom$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["filter"])(function (z) {
            return z > 0;
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (z) {
            return z / 100;
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])(function (z) {
            return console.log('Setting zoom to', z);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])(function (z) {
            return !!window.require ? window.require('electron').webFrame.setZoomFactor(z) : void 0;
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["mergeMap"])(function (z) {
            return _this45._cache.store('app-zoom', z * 100);
          })); // Initialise zoom

          this._cache.get('app-zoom').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (z) {
            return _this45.zoom$.next(z);
          })).subscribe(function () {
            return _this45.doZoom$.subscribe();
          });
        }
      }, {
        key: "setZoom",
        value: function setZoom(zoom) {
          console.log('Zoom changed to:', zoom);
          this.zoom$.next(zoom);
        }
      }]);

      return ZoomService;
    }();

    ZoomService.ɵfac = function ZoomService_Factory(t) {
      return new (t || ZoomService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_cache_cache_service__WEBPACK_IMPORTED_MODULE_3__["CacheService"]));
    };

    ZoomService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: ZoomService,
      factory: ZoomService.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ZoomService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _cache_cache_service__WEBPACK_IMPORTED_MODULE_3__["CacheService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/shared/components/top-bar/top-bar.component.ts":
  /*!****************************************************************!*\
    !*** ./src/app/shared/components/top-bar/top-bar.component.ts ***!
    \****************************************************************/

  /*! exports provided: TopBarComponent */

  /***/
  function srcAppSharedComponentsTopBarTopBarComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TopBarComponent", function () {
      return TopBarComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var _c0 = ["topbar"];
    var _c1 = ["*"];

    var TopBarComponent = /*#__PURE__*/function () {
      function TopBarComponent() {
        _classCallCheck(this, TopBarComponent);
      }

      _createClass(TopBarComponent, [{
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {
          this.el = this.topbar.el;
        }
      }]);

      return TopBarComponent;
    }();

    TopBarComponent.ɵfac = function TopBarComponent_Factory(t) {
      return new (t || TopBarComponent)();
    };

    TopBarComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: TopBarComponent,
      selectors: [["app-top-bar"]],
      viewQuery: function TopBarComponent_Query(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, true);
        }

        if (rf & 2) {
          var _t;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.topbar = _t.first);
        }
      },
      ngContentSelectors: _c1,
      decls: 4,
      vars: 0,
      consts: [["color", "dark", "id", "topbar"], ["topbar", ""]],
      template: function TopBarComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header", 0, 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ion-toolbar");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      },
      directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonToolbar"]],
      styles: ["ion-toolbar[_ngcontent-%COMP%] {\r\n    image-rendering: optimizeQuality;\r\n    image-rendering: -moz-crisp-edges; \r\n    image-rendering: -o-crisp-edges; \r\n    image-rendering: -webkit-optimize-contrast; \r\n    image-rendering: crisp-edges;\r\n    --background: var(--ion-color-light) url('logo-marker.png') no-repeat center/40px\r\n}\r\n@media (prefers-color-scheme: dark) {\r\n    ion-toolbar[_ngcontent-%COMP%] {\r\n        --background: var(--ion-color-light) url('logo-white.png') no-repeat center/40px\r\n    }\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvdG9wLWJhci90b3AtYmFyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEscUJBQXFCO0FBQ3JCO0lBQ0ksZ0NBQWdDO0lBQ2hDLGlDQUFpQyxFQUFFLFlBQVk7SUFDL0MsK0JBQStCLEVBQUUsVUFBVTtJQUMzQywwQ0FBMEMsRUFBRSxpQ0FBaUM7SUFDN0UsNEJBQTRCO0lBQzVCO0FBQ0o7QUFDQTtJQUNJO1FBQ0k7SUFDSjtBQUNKIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvdG9wLWJhci90b3AtYmFyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBUb29sYmFyIEJyYW5kaW5nICovXHJcbmlvbi10b29sYmFyIHtcclxuICAgIGltYWdlLXJlbmRlcmluZzogb3B0aW1pemVRdWFsaXR5O1xyXG4gICAgaW1hZ2UtcmVuZGVyaW5nOiAtbW96LWNyaXNwLWVkZ2VzOyAvKiBGaXJlZm94ICovXHJcbiAgICBpbWFnZS1yZW5kZXJpbmc6IC1vLWNyaXNwLWVkZ2VzOyAvKiBPcGVyYSAqL1xyXG4gICAgaW1hZ2UtcmVuZGVyaW5nOiAtd2Via2l0LW9wdGltaXplLWNvbnRyYXN0OyAvKiBXZWJraXQgKG5vbi1zdGFuZGFyZCBuYW1pbmcpICovXHJcbiAgICBpbWFnZS1yZW5kZXJpbmc6IGNyaXNwLWVkZ2VzO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpIHVybCgnLi4vLi4vLi4vLi4vYXNzZXRzL2ltYWdlcy9sb2dvLW1hcmtlci5wbmcnKSBuby1yZXBlYXQgY2VudGVyLzQwcHhcclxufVxyXG5AbWVkaWEgKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKSB7XHJcbiAgICBpb24tdG9vbGJhciB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpIHVybCgnLi4vLi4vLi4vLi4vYXNzZXRzL2ltYWdlcy9sb2dvLXdoaXRlLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIvNDBweFxyXG4gICAgfVxyXG59Il19 */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](TopBarComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-top-bar',
          templateUrl: './top-bar.component.html',
          styleUrls: ['./top-bar.component.css']
        }]
      }], null, {
        topbar: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
          args: ['topbar']
        }]
      });
    })();
    /***/

  },

  /***/
  "./src/app/shared/guards/signed-in.guard.ts":
  /*!**************************************************!*\
    !*** ./src/app/shared/guards/signed-in.guard.ts ***!
    \**************************************************/

  /*! exports provided: SignedInGuard */

  /***/
  function srcAppSharedGuardsSignedInGuardTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SignedInGuard", function () {
      return SignedInGuard;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../services/auth/auth.service */
    "./src/app/services/auth/auth.service.ts");

    var SignedInGuard = /*#__PURE__*/function () {
      function SignedInGuard(auth, router) {
        _classCallCheck(this, SignedInGuard);

        this.auth = auth;
        this.router = router;
      }

      _createClass(SignedInGuard, [{
        key: "canActivate",
        value: function canActivate(next, state) {
          var _this46 = this;

          // Check user is logged in
          return this.auth.isLoggedIn().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (u) {
            return console.log('SignedIn Guard - Retrieved auth from service', u);
          }), // Return true, or redirect to login/authorize
          Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["mergeMap"])(function (u) {
            return !!u ? Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(true) : _this46.auth.hasSession().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (e) {
              return console.log('SignedIn Guard - User exists in cache', e);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (e) {
              return !!e ? _this46.router.navigate(['/authorize'], {
                queryParams: {
                  redirect: state.url
                }
              }) : _this46.router.navigate(['/login']);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function () {
              return false;
            }));
          }));
        }
      }, {
        key: "canActivateChild",
        value: function canActivateChild(next, state) {
          return this.canActivate(next, state);
        }
      }]);

      return SignedInGuard;
    }();

    SignedInGuard.ɵfac = function SignedInGuard_Factory(t) {
      return new (t || SignedInGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]));
    };

    SignedInGuard.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: SignedInGuard,
      factory: SignedInGuard.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](SignedInGuard, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/shared/guards/signed-out.guard.ts":
  /*!***************************************************!*\
    !*** ./src/app/shared/guards/signed-out.guard.ts ***!
    \***************************************************/

  /*! exports provided: SignedOutGuard */

  /***/
  function srcAppSharedGuardsSignedOutGuardTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SignedOutGuard", function () {
      return SignedOutGuard;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! src/app/services/auth/auth.service */
    "./src/app/services/auth/auth.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var SignedOutGuard = /*#__PURE__*/function () {
      function SignedOutGuard(auth) {
        _classCallCheck(this, SignedOutGuard);

        this.auth = auth;
      }

      _createClass(SignedOutGuard, [{
        key: "canActivate",
        value: function canActivate(next, state) {
          return this.auth.isLoggedIn().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (t) {
            return !t;
          }));
        }
      }, {
        key: "canActivateChild",
        value: function canActivateChild(next, state) {
          return this.canActivate(next, state);
        }
      }]);

      return SignedOutGuard;
    }();

    SignedOutGuard.ɵfac = function SignedOutGuard_Factory(t) {
      return new (t || SignedOutGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"]));
    };

    SignedOutGuard.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: SignedOutGuard,
      factory: SignedOutGuard.ɵfac,
      providedIn: 'root'
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](SignedOutGuard, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: 'root'
        }]
      }], function () {
        return [{
          type: src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/shared/interceptors/jwt.interceptor.ts":
  /*!********************************************************!*\
    !*** ./src/app/shared/interceptors/jwt.interceptor.ts ***!
    \********************************************************/

  /*! exports provided: JwtInterceptor */

  /***/
  function srcAppSharedInterceptorsJwtInterceptorTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "JwtInterceptor", function () {
      return JwtInterceptor;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../services/auth/auth.service */
    "./src/app/services/auth/auth.service.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");

    var JwtInterceptor = /*#__PURE__*/function () {
      function JwtInterceptor(auth) {
        _classCallCheck(this, JwtInterceptor);

        this.auth = auth;
      }

      _createClass(JwtInterceptor, [{
        key: "intercept",
        value: function intercept(request, next) {
          var _this47 = this;

          // Only add auth to requests for our API
          return request.url.startsWith(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl) ? this.auth.isLoggedIn().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(function (u) {
            return !!_this47.auth.getToken() ? "Bearer ".concat(_this47.auth.getToken()) : '';
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(function (Authorization) {
            return request.clone(Authorization ? {
              setHeaders: {
                Authorization: Authorization
              },
              withCredentials: true
            } : undefined);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(function (r) {
            return next.handle(r);
          })) : next.handle(request);
        }
      }]);

      return JwtInterceptor;
    }();

    JwtInterceptor.ɵfac = function JwtInterceptor_Factory(t) {
      return new (t || JwtInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]));
    };

    JwtInterceptor.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: JwtInterceptor,
      factory: JwtInterceptor.ɵfac
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](JwtInterceptor, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
      }], function () {
        return [{
          type: _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var zone_js_dist_zone_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! zone.js/dist/zone-error */
    "./node_modules/zone.js/dist/zone-error.js");
    /* harmony import */


    var zone_js_dist_zone_error__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(zone_js_dist_zone_error__WEBPACK_IMPORTED_MODULE_0__); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false,
      // API: Server URL
      apiUrl: 'https://api.wallet.nygmarosebeauty.com/api/v1',
      appUrl: 'https://wallet.nygmarosebeauty.com',
      // API: Exchange Rates API
      fx: {
        url: 'https://openexchangerates.org/api/latest.json',
        client_id: 'c56480251bae4d4ca59f1ff85d954429'
      },
      // API: Stripe Details
      stripe: {
        client_id: 'ca_Dtemp3RTqA3RHzlGbSxwdAKTTn4n6fGl',
        public_key: 'pk_test_q4I6d4V8onnBC31PJOdKjY8i'
      },
      // API: Firbase Services
      firebase: {
        apiKey: "AIzaSyAIrCRt4FSgS4DMUTZj2xUMMSymAtCq0Wk",
        authDomain: "nr-wallet-5e82a.firebaseapp.com",
        databaseURL: "https://nr-wallet-5e82a.firebaseio.com",
        projectId: "nr-wallet-5e82a",
        storageBucket: "nr-wallet-5e82a.appspot.com",
        messagingSenderId: "427082487138",
        appId: "1:427082487138:web:698543e31791e68601083b",
        measurementId: "G-7C9PRZ0J72"
      },
      fcm: {
        topics: ['test'],
        iconColor: 'black',
        icon: 'assets/images/logo',
        channels: {
          'PushPluginChannel': 'Miscellaneous',
          'transfers': 'Transfers',
          'payouts': 'Withdrawls',
          'payment_methods': 'Payment Sources'
        }
      },
      cache: {
        name: 'flow',
        description: 'Flow local storage cache',
        store: 'flow_cache'
      },
      themes: {
        purple: ''
      },
      runes: [{
        quote: 'NR Donates 10% of all Income to Non-Profit Organisations Across the World!',
        author: 'NygmaRose'
      }, {
        quote: 'At NR We Make All Our Apps Open Source and Available to All. You Can See Our Projects at Github.com/NygmaRose.',
        author: 'NygmaRose'
      }, {
        quote: 'NR Has a Goal to Help the World. At NR We Strive to Partner and Promote as Many Non-Profit Organisations as We Can. Tweet Us Some to Explore New Opportunities!',
        author: 'NygmaRose'
      }]
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @ionic/pwa-elements/loader */
    "./node_modules/@ionic/pwa-elements/loader/index.es2017.mjs");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
    }

    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"]).then(function () {
      return Object(_ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_1__["defineCustomElements"])(window);
    })["catch"](function (err) {
      return console.error;
    });
    /***/

  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! C:\Users\ASUS\Documents\Projects\ulfur\flow\src\main.ts */
    "./src/main.ts");
    /***/
  },

  /***/
  1:
  /*!************************!*\
    !*** crypto (ignored) ***!
    \************************/

  /*! no static exports found */

  /***/
  function _(module, exports) {
    /* (ignored) */

    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map